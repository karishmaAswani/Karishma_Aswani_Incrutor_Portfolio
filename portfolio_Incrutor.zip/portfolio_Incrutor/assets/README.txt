Place your resume PDF in this folder.

Recommended file name:
- resume.pdf

If you use a different file name, update the link in index.html.
